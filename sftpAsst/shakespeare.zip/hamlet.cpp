#include <iostream>

using namespace std;

int main()
{
  cout << "To be, or not to be?" << endl;
  cout << "Hello, Hamlet!" << endl;
  return 0;
}
